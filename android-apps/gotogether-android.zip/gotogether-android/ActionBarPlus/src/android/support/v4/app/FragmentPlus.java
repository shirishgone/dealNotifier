
package android.support.v4.app;


public abstract class FragmentPlus extends Fragment{

    protected int getContainerId() {
        return mContainerId;
    }
}
